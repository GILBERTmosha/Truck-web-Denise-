"use client"

import Link from "next/link"
import { Truck, ShoppingCart, User } from "lucide-react"
import { Button } from "@/components/ui/button"

interface HeaderProps {
  onLoginClick: () => void
}

export function Header({ onLoginClick }: HeaderProps) {
  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-2">
            <Truck className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold tracking-tight text-foreground">
              TruckZone
            </span>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            <Link
              href="#games"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Games
            </Link>
            <Link
              href="#stickers"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Stickers
            </Link>
            <Link
              href="#about"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              About
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-foreground">
              <ShoppingCart className="h-5 w-5" />
              <span className="sr-only">Shopping cart</span>
            </Button>
            <Button
              onClick={onLoginClick}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              <User className="h-4 w-4 mr-2" />
              Sign In
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
