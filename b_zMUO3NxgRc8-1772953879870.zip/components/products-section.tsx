import { ProductCard } from "./product-card"

const games = [
  {
    title: "Truck Simulator Pro",
    price: 29.99,
    originalPrice: 49.99,
    image: "/images/game-1.jpg",
  },
  {
    title: "Off-Road Monster",
    price: 19.99,
    image: "/images/game-2.jpg",
  },
  {
    title: "Highway Hauler",
    price: 24.99,
    originalPrice: 34.99,
    image: "/images/game-3.jpg",
  },
  {
    title: "Extreme Trucking",
    price: 14.99,
    image: "/images/game-4.jpg",
  },
]

const stickers = [
  {
    title: "Monster Truck Decal Pack",
    price: 9.99,
    originalPrice: 14.99,
    image: "/images/sticker-1.jpg",
  },
  {
    title: "Vintage Trucker Badge",
    price: 4.99,
    image: "/images/sticker-2.jpg",
  },
  {
    title: "Racing Flames Set",
    price: 7.99,
    image: "/images/sticker-3.jpg",
  },
  {
    title: "Custom Logo Pack",
    price: 12.99,
    originalPrice: 19.99,
    image: "/images/sticker-4.jpg",
  },
]

export function ProductsSection() {
  return (
    <div className="bg-background py-20">
      <section id="games" className="container mx-auto px-4 mb-20">
        <div className="text-center mb-12">
          <p className="text-primary font-semibold tracking-widest uppercase text-sm mb-2">
            Featured Collection
          </p>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            Truck Games
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {games.map((game) => (
            <ProductCard
              key={game.title}
              title={game.title}
              price={game.price}
              originalPrice={game.originalPrice}
              image={game.image}
              category="game"
            />
          ))}
        </div>
      </section>

      <section id="stickers" className="container mx-auto px-4">
        <div className="text-center mb-12">
          <p className="text-primary font-semibold tracking-widest uppercase text-sm mb-2">
            Express Yourself
          </p>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            Truck Stickers
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {stickers.map((sticker) => (
            <ProductCard
              key={sticker.title}
              title={sticker.title}
              price={sticker.price}
              originalPrice={sticker.originalPrice}
              image={sticker.image}
              category="sticker"
            />
          ))}
        </div>
      </section>
    </div>
  )
}
