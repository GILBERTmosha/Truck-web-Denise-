"use client"

import { useState } from "react"
import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { ProductsSection } from "@/components/products-section"
import { Footer } from "@/components/footer"
import { LoginModal } from "@/components/login-modal"

export default function HomePage() {
  const [isLoginOpen, setIsLoginOpen] = useState(false)

  return (
    <main className="min-h-screen bg-background">
      <Header onLoginClick={() => setIsLoginOpen(true)} />
      <Hero />
      <ProductsSection />
      <Footer />
      <LoginModal isOpen={isLoginOpen} onClose={() => setIsLoginOpen(false)} />
    </main>
  )
}
